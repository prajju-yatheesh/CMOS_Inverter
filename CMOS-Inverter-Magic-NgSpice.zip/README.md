# CMOS Inverter using Magic VLSI & NgSpice

## 📌 Project Overview
This project demonstrates the design, layout, and simulation of a CMOS inverter using:
- **Magic VLSI** (for layout, DRC, LVS)
- **NgSpice** (for circuit simulation)

Key steps:
- Designed CMOS inverter layout in Magic
- Performed **DRC** (Design Rule Check) & **LVS** (Layout vs Schematic)
- Extracted netlist from Magic
- Simulated in NgSpice with capacitive load
- Measured **propagation delay** and **power consumption**

---

## 🗂 Project Structure
```
CMOS-Inverter-Magic-NgSpice/
│── layout/        → Magic layout files (.mag)
│── spice/         → SPICE netlist + testbench
│── results/       → Waveforms & reports
└── README.md      → Project documentation
```

---

## 🚀 How to Run

### 1. Open Layout in Magic
```bash
magic -T sky130A.tech cmos_inverter.mag
```
- Run `drc check` for design rule check
- Run `extract all` and `ext2spice` to generate netlist

### 2. Run SPICE Simulation
```bash
ngspice testbench.spice
```
- Outputs waveforms of **Vin** and **Vout**
- Reports propagation delay (tPLH, tPHL) and average power

---

## 📊 Results
- Inverter shows correct logic inversion
- Propagation delay measured with 10fF capacitive load
- Average power consumption calculated

(See `/results/` for plots and reports)

---

## 🛠 Tools Used
- **Magic VLSI**
- **NgSpice**
- **SkyWater 130nm PDK**

---

## 👤 Author
Satwik Kamath
